import { Button, TextField, Typography } from '@mui/material'
import React from 'react'

const Signup = () => {
  return (
    <div>
      <Typography variant='h4'>Signup</Typography><br /><br></br>
      <TextField variant='outlined' label="Username"></TextField><br /><br></br>
      <TextField variant='outlined' label="Place"></TextField><br /><br></br>
      <TextField variant='outlined' label="Age"></TextField><br /><br></br>
      <TextField variant='outlined' label="Gender"></TextField><br /><br></br>
      <TextField variant='outlined' label="Email"></TextField><br /><br></br>
      <TextField variant='outlined' label="password" type='password'></TextField><br /><br></br>
      <Button variant='contained'>Signup</Button>
    </div>
  )
}

export default Signup
