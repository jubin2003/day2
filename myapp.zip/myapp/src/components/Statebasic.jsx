import { Button, TextField, Typography } from '@mui/material'
import React, { useState } from 'react'

const Statebasic = () => {

   // var name = "Jubin"
   var[fname,setFname] = useState("Jubin")
   var[val,setva1]=useState()
      const changeName =() =>{
       console.log("Clicked")
       setFname(val)
       setva1("")
      }
      const inputhandler=(e)=>{
        console.log(e.target.value)
        setva1(e.target.value)
      }
  return (
    <div>
      <Typography>My Name is:{fname}</Typography>
      <TextField variant="outlined" label="Enter Name" onChange={inputhandler} value={val}></TextField><br></br>
      <Button variant='contained' onClick={changeName}>Change</Button>
    </div>
  )
}

export default Statebasic
