import React, { useState } from 'react'

const Mapping = () => {
    var[name,setname] = useState(["Jubin","Thomas","P"])
  return (
    <div>
 <ul>
    {name.map((value,index)=>{
       return(
        <li>{value}</li>
    )
    })}
    
        
    
 </ul>
       
    </div>
  )
}

export default Mapping