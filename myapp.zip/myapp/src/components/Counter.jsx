import { Button, Typography } from '@mui/material'
import React, { useState } from 'react'

const Counter = () => {
    var [count,Setnum] = useState(0);
    const Incr =() =>{
        Setnum(count =count+1)
       
    }
    const dec =() =>{
        if(count>0){
            Setnum(count =count-1)
          
        }
       
    }
  return (
    <div>
        <Typography>Count:{count}</Typography>
        <Button variant='contained'onClick={Incr} color='success'>+</Button> &nbsp;&nbsp;
        <Button variant='contained' onClick={dec} color='error'>-</Button>
    </div>
    
  )
}

export default Counter