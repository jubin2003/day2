import { Button, Typography } from '@mui/material'
import React, { useEffect, useState } from 'react'

const UseE = () => {
    var[name,setName] =useState("");
    const onhome =()=>{
    setName("Home")
    }
    const oncontact =() =>{
        setName("Contact")
    }
    const ongallery =() =>{
        setName("Gallery")
    }
    useEffect(()=>{
        onhome()
    },[])
  return (
    <div>
        <Typography>Welcome to {name}</Typography>
        <Button variant='contained' onClick={onhome}>Home</Button> &nbsp;&nbsp;
        <Button variant='contained' onClick={oncontact}>Contact</Button>&nbsp;&nbsp;
        <Button variant='contained' onClick={ongallery}>Gallery</Button>
    </div>
  )
}

export default UseE