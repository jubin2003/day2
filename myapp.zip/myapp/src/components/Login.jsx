import { TextField, Typography } from '@mui/material'
import React from 'react'
// rafec
function Login() {
    return (
        <div>
        /* <TextField variant='outlined' label='Email'/><br></br>
        <TextField variant='outlined' label='Password' type='password'/><br></br>
        <button>Login</button> */
        </div>
    )
}

export default Login
